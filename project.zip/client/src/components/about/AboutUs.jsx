import Layout from "../Layout";

export default function AboutUs() {
    return (
        <Layout>
            <h1>about us page</h1>
        </Layout>
    )
}